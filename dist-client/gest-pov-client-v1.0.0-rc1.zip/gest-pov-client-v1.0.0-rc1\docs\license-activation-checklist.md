# Checklist activation licence client � Gest_POV

## Contexte

- Environnement : Docker client (`docker-compose.client.yml`, profil `prod,docker`)
- Fichier retour attendu : `gest_pov.lic`

> **Ne jamais committer :** `.env`, `gest_pov.lic`, `backups/`, cl�s priv�es, archives `images/*.tar`.

---

## R�cup�rer l'installation ID (c�t� client)

```bash
curl -s http://127.0.0.1/api/license/installation-id
# ou
docker exec gest-pov-backend cat /app/gest-pov-data/installation.id
```

Conserver cet UUID pour la demande �diteur � **ne pas r�utiliser un ID issu d'un smoke test dev**.

## Informations � envoyer � l'�diteur

- Installation ID : `<INSTALLATION_ID_CLIENT>`
- Produit attendu (`app`) : `gest_pov`
- Nom client : `<A_COMPLETER_PAR_LE_CLIENT>`
- Site client : `<A_COMPLETER>`
- Edition / plan : `<STANDARD|PRO|ENTERPRISE>`
- Date d'expiration souhait�e : `<YYYY-MM-DD>`
- Limite utilisateurs (`maxUsers`) : `<NOMBRE>`

## Attendu c�t� �diteur (hors projet client)

1. G�n�rer la licence avec la **cl� priv�e production** (jamais livr�e au client).
2. Signer la payload avec RSA SHA256.
3. V�rifier que `installationId` correspond exactement.
4. Renvoyer un fichier nomm� `gest_pov.lic`.
5. Transmettre le fichier via canal s�curis� (pas Git).

## Proc�dure c�t� client � r�ception de `gest_pov.lic`

```bash
curl -X POST http://127.0.0.1/api/license/import \
  -F "file=@gest_pov.lic"

curl -s http://127.0.0.1/api/license/status
```

R�sultat attendu : `valid=true`, `activated=true`.

## Validation fonctionnelle apr�s activation

- [ ] Login admin bootstrap (`/api/auth/login`) ? HTTP 200
- [ ] `GET /api/products` avec token admin ? HTTP 200 (plus de `403 LICENSE_REQUIRED`)
- [ ] `docker compose -f docker-compose.client.yml --env-file .env restart`
- [ ] `GET /api/license/status` reste `valid=true` apr�s restart
- [ ] `GET /api/auth/me` avec token admin ? HTTP 200
- [ ] `installationId` inchang� apr�s restart
- [ ] `./scripts/client-backup.sh` ? `<BACKUP_DIR>/` contient `postgres.dump`, `installation.id`, `gest_pov.lic`

## Si la licence n'est pas encore disponible

- Statut attendu : `LICENSE_MISSING`.
- API m�tier reste bloqu�e : `403 LICENSE_REQUIRED`.
- Aucune action de contournement n'est autoris�e.

---

## Exemple local non client (poste dev � 2026-07-02)

Validation effectu�e sur une installation Docker vierge locale. **Ne pas traiter comme documentation client livrable.**

| �tape | R�sultat |
|-------|----------|
| Install vierge + bootstrap | OK |
| Import `gest_pov.lic` �diteur | OK � `valid=true`, `activated=true` |
| `/api/products`, `/api/auth/me` | HTTP 200 |
| Restart stack (`docker compose � restart`) | OK � licence toujours `valid=true`, ID inchang� |
| Backup post-restart | OK � `backups/<timestamp>/` avec `gest_pov.lic` + `installation.id` |

L'`installationId` r�el est stock� uniquement dans le volume licence local et les backups gitignored � **ne pas le copier dans le d�p�t Git**.

---

Voir aussi : `docs/license-production.md`, `docs/release-readiness-v1.md`, `docs/next-release-steps.md`.
