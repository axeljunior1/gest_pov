# Gest_POV LicGen

Générateur de licences **éditeur**, totalement séparé du dépôt / runtime Gest_POV.

- Aucune dépendance npm (Node.js 18+ uniquement)
- Clé privée conservée **uniquement** sur la machine de l'éditeur
- Produit des fichiers `.lic` compatibles avec l'écran d'activation Gest_POV

## Installation

```bash
cd gest-pov-licgen
```

Aucun `npm install` requis.

### Première utilisation — clés RSA

Si `keys/private_key.pem` n'existe pas encore :

```bash
node bin/licgen.mjs keygen
```

Copiez ensuite `keys/public_key.pem` dans l'application cliente :

```text
gest-pov/backend/src/main/resources/keys/public_key.pem
```

Redémarrez le backend Gest_POV.

> **Important** : la clé privée ne doit jamais être livrée au client ni commitée (déjà dans `.gitignore`).

## Générer une licence (CLI)

```bash
node bin/licgen.mjs generate 
  --installation-id "eb3c5be2-9bc4-4151-a279-8d67e98a816d" 
  --client "Ma société" 
  --expires 2027-12-31 
  --max-users 10 
  --out gest_pov.lic
```

Le client importe `gest_pov.lic` depuis l'écran d'activation Gest_POV.

## Interface web locale (optionnel)

```bash
node bin/licgen.mjs serve
```

Ouvrir [http://127.0.0.1:4000](http://127.0.0.1:4000) — **usage local uniquement**, ne pas exposer sur Internet.

## Vérifier une licence

```bash
node bin/licgen.mjs verify --file gest_pov.lic
```

## Format technique

Fichier JSON :

```json
{
  "payload": "<base64 du JSON métier>",
  "signature": "<RSA SHA256 sur la chaîne base64 du payload>"
}
```

Payload décodé :


| Champ            | Description                  |
| ---------------- | ---------------------------- |
| `app`            | `gest_pov`                   |
| `installationId` | Identifiant machine Gest_POV |
| `client`, `site` | Client / site                |
| `expiresAt`      | `YYYY-MM-DD`                 |
| `maxUsers`       | Limite utilisateurs actifs   |
| `licenseId`      | Référence licence            |


## Windows (PowerShell)

```powershell
.\licgen.ps1 generate -InstallationId "uuid..." -Client "Test" -Expires "2027-12-31"
```

