param(
  [Parameter(Position = 0)]
  [ValidateSet('keygen', 'generate', 'verify', 'serve', 'help')]
  [string]$Command = 'help',

  [Alias('InstallationId', 'MachineId')]
  [string]$InstallationId,

  [string]$Client,
  [string]$Expires,
  [int]$MaxUsers = 5,
  [string]$Site,
  [string]$Out = 'gest_pov.lic',
  [string]$File,
  [int]$Port = 4000
)

$root = $PSScriptRoot
$licgen = Join-Path $root 'bin\licgen.mjs'

switch ($Command) {
  'keygen' {
    node $licgen keygen
  }
  'generate' {
    if (-not $InstallationId -or -not $Client -or -not $Expires) {
      Write-Error 'generate requiert -InstallationId, -Client et -Expires'
      exit 1
    }
    $args = @(
      'generate',
      '--installation-id', $InstallationId,
      '--client', $Client,
      '--expires', $Expires,
      '--max-users', $MaxUsers,
      '--out', $Out
    )
    if ($Site) { $args += @('--site', $Site) }
    node $licgen @args
  }
  'verify' {
    if (-not $File) { $File = 'gest_pov.lic' }
    node $licgen verify --file $File
  }
  'serve' {
    node $licgen serve --port $Port
  }
  default {
    node $licgen --help
  }
}
